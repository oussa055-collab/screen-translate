package com.screentranslate

import java.text.SimpleDateFormat
import java.util.*

/** Small in-memory log shown live in the main screen. */
object AppLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized fun add(m: String) {
        lines.addLast("${fmt.format(Date())}  $m")
        while (lines.size > 120) lines.removeFirst()
    }
    @Synchronized fun text(n: Int = 40) = lines.toList().takeLast(n).reversed().joinToString("\n")
    @Synchronized fun all() = lines.toList().joinToString("\n")
    @Synchronized fun clear() = lines.clear()
}
