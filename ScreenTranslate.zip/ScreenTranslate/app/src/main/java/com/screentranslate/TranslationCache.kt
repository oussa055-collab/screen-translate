package com.screentranslate

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

/** Persistent translation cache (survives app close) with fuzzy matching of near-identical sentences. */
object TranslationCache {
    private const val MAX = 6000
    private const val MAX_DIFF = 0.2          // up to 20% different characters = "same sentence"
    private val map = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > MAX
    }
    private var file: File? = null
    private val io = Executors.newSingleThreadExecutor()
    private var pending = false

    @Synchronized fun init(ctx: Context) {
        if (file != null) return
        val f = File(ctx.applicationContext.filesDir, "translation_cache.json"); file = f
        try {
            if (f.exists()) {
                val o = JSONObject(f.readText()); val it = o.keys()
                while (it.hasNext()) { val k = it.next(); map[k] = o.getString(k) }
            }
            AppLog.add("💾 الكاش: ${map.size} جملة محفوظة")
        } catch (e: Exception) { AppLog.add("⚠ الكاش: ${e.message}") }
    }

    private fun norm(src: String, t: String) = src + "|" + t.filter { it.isLetterOrDigit() }.take(120)

    @Synchronized fun size() = map.size

    @Synchronized fun get(src: String, t: String): String? = map[norm(src, t)]

    /** Closest cached sentence (same source language) within MAX_DIFF, or null. */
    @Synchronized fun getSimilar(src: String, t: String): String? {
        val x = norm(src, t).substringAfter('|')
        if (x.length < 4) return null
        val pre = "$src|"
        var best: String? = null; var bd = Int.MAX_VALUE
        for ((k, v) in map) {
            if (!k.startsWith(pre)) continue
            val y = k.substring(pre.length)
            val m = maxOf(x.length, y.length); val lim = (m * MAX_DIFF).toInt()
            if (abs(x.length - y.length) > lim) continue
            val d = dist(x, y, lim)
            if (d <= lim && d < bd) { bd = d; best = v; if (d == 0) break }
        }
        return best
    }

    private fun dist(x: String, y: String, lim: Int): Int {
        var prev = IntArray(y.length + 1) { it }
        for (i in 1..x.length) {
            val cur = IntArray(y.length + 1); cur[0] = i; var mn = i
            for (j in 1..y.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (x[i - 1] == y[j - 1]) 0 else 1)
                if (cur[j] < mn) mn = cur[j]
            }
            if (mn > lim) return lim + 1
            prev = cur
        }
        return prev[y.length]
    }

    @Synchronized fun put(src: String, t: String, tr: String) {
        map[norm(src, t)] = tr
        if (!pending) { pending = true; io.execute { Thread.sleep(3000); save() } }
    }

    @Synchronized fun clear() { map.clear(); file?.delete() }

    fun flush() { io.execute { save() } }

    private fun save() {
        val json: String; val f: File
        synchronized(this) {
            pending = false; f = file ?: return
            val o = JSONObject(); for ((k, v) in map) o.put(k, v); json = o.toString()
        }
        try {
            val tmp = File(f.parentFile, f.name + ".tmp"); tmp.writeText(json)
            if (!tmp.renameTo(f)) { f.writeText(json); tmp.delete() }
        } catch (_: Exception) {}
    }
}
