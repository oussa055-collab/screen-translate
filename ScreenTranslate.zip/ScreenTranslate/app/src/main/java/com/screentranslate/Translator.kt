package com.screentranslate

import android.content.SharedPreferences
import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Round-robin over enabled servers, automatic failover, cooldown for a failing server. */
object Translator {
    private val cool = ConcurrentHashMap<String, Long>()
    private var rr = 0
    @Volatile var lastError = ""
    private val ALL = listOf("Google Translate", "Groq", "Gemini", "OpenRouter")
    private var groqModel = ""
    private var groqModelKey = ""

    private fun http(url: String, body: String?, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 7000
        headers.forEach { c.setRequestProperty(it.key, it.value) }
        if (body != null) { c.requestMethod = "POST"; c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw Exception("HTTP $code" + if (url.contains("google")) "" else " " + s.take(90).replace("\n", " "))
        return s
    }

    private fun enc(t: String) = URLEncoder.encode(t, "UTF-8")
    private fun sl(src: String) = if (src == "zh") "zh-CN" else src

    // Three different free Google endpoints; each one has its own cooldown.
    private fun google(text: String, src: String): String {
        var err = ""
        val ua = mapOf("User-Agent" to "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        val variants = listOf<Pair<String, () -> String>>(
            "g1" to {
                val a = JSONArray(http("https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl(src)}&tl=ar&dt=t&q=${enc(text)}", null, ua)).getJSONArray(0)
                (0 until a.length()).joinToString("") { a.getJSONArray(it).optString(0, "") }
            },
            "g2" to {
                val r = http("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=${sl(src)}&tl=ar&q=${enc(text)}", null, ua).trim()
                if (r.startsWith("{")) { val a = JSONObject(r).getJSONArray("sentences"); (0 until a.length()).joinToString("") { a.getJSONObject(it).optString("trans", "") } }
                else { val a = JSONArray(r); val f = a.get(0); if (f is JSONArray) f.optString(0) else a.optString(0) }
            },
            "g3" to {
                val h = http("https://translate.google.com/m?sl=${sl(src)}&tl=ar&q=${enc(text)}", null, ua)
                val k = "class=\"result-container\">"; val i = h.indexOf(k)
                if (i < 0) throw Exception("no result")
                Html.fromHtml(h.substring(i + k.length, h.indexOf("</div>", i)), Html.FROM_HTML_MODE_LEGACY).toString()
            }
        )
        for ((n, f) in variants) {
            if ((cool[n] ?: 0L) > System.currentTimeMillis()) continue
            try { val r = f().trim(); if (r.isNotEmpty()) return r }
            catch (e: Exception) { err += "$n:${e.message} "; cool[n] = System.currentTimeMillis() + (if (e.message?.contains("429") == true) 120000 else 20000) }
        }
        throw Exception(err.ifBlank { "all Google endpoints cooling down" })
    }

    private fun myMemory(text: String, src: String): String {
        val r = JSONObject(http("https://api.mymemory.translated.net/get?q=${enc(text)}&langpair=${sl(if (src == "auto") "zh" else src)}|ar", null))
        return r.getJSONObject("responseData").getString("translatedText")
    }

    private fun prompt(text: String) = "Translate this subtitle to Arabic. Output only the Arabic translation, nothing else:\n$text"

    private fun gemini(key: String, text: String): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt(text)))))).toString()
        val r = JSONObject(http("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key", body, mapOf("Content-Type" to "application/json")))
        return r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
    }

    private fun chat(url: String, key: String, model: String, text: String): String {
        val o = JSONObject().put("model", model).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt(text))))
        if (model.startsWith("openai/gpt-oss")) o.put("reasoning_effort", "low")
        val r = JSONObject(http(url, o.toString(), mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key")))
        return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }

    // Groq's model catalog changes often: ask the API which models exist for this key.
    private fun pickGroqModel(key: String): String {
        if (groqModel.isNotEmpty() && groqModelKey == key) return groqModel
        val a = JSONObject(http("https://api.groq.com/openai/v1/models", null, mapOf("Authorization" to "Bearer $key"))).getJSONArray("data")
        val ids = (0 until a.length()).map { a.getJSONObject(it).getString("id") }
        val pref = listOf("openai/gpt-oss-20b", "llama-3.3-70b-versatile", "openai/gpt-oss-120b", "llama-3.1-8b-instant")
        val m = pref.firstOrNull { it in ids }
            ?: ids.firstOrNull { id -> listOf("whisper", "tts", "guard", "orpheus", "compound", "embed").none { id.contains(it) } }
            ?: throw Exception("no Groq model available")
        AppLog.add("Groq model: $m"); groqModel = m; groqModelKey = key
        return m
    }

    private fun call(s: String, p: SharedPreferences, text: String, src: String): String {
        val k = p.getString("key_$s", "")!!.trim()
        return when (s) {
            "Gemini" -> gemini(k, text)
            "Groq" -> chat("https://api.groq.com/openai/v1/chat/completions", k, pickGroqModel(k), text)
            "OpenRouter" -> chat("https://openrouter.ai/api/v1/chat/completions", k, "openrouter/auto", text)
            else -> google(text, src)
        }
    }

    fun translate(p: SharedPreferences, text: String): String? {
        val src = p.getString("src", "zh")!!
        val on = ALL.filter { val hasKey = p.getString("key_$it", "")!!.isNotBlank(); p.getBoolean("on_$it", it == "Google Translate" || hasKey) && (it == "Google Translate" || hasKey) }
            .ifEmpty { listOf("Google Translate") }
        val start = synchronized(this) { rr++ }
        val order = on.indices.map { on[(start + it) % on.size] }
        val now = System.currentTimeMillis()
        val errs = ArrayList<String>()
        val ready = order.filter { (cool[it] ?: 0L) < now }.ifEmpty { order }
        for (s in ready) {
            AppLog.add("→ $s")
            try { val r = call(s, p, text, src); if (r.isNotBlank()) { AppLog.add("✓ $s: ${r.take(40)}"); return r } }
            catch (e: Exception) { AppLog.add("✗ $s: ${e.message}"); errs.add("$s: ${e.message}"); cool[s] = now + (if (e.message?.contains("429") == true) 90000 else 30000) }
        }
        // last resort: free MyMemory (lower quality, small daily quota)
        AppLog.add("→ MyMemory")
        try { val r = myMemory(text, src); if (r.isNotBlank()) { AppLog.add("✓ MyMemory: ${r.take(40)}"); return r } }
        catch (e: Exception) { AppLog.add("✗ MyMemory: ${e.message}"); errs.add("MyMemory: ${e.message}") }
        lastError = errs.joinToString("  |  ")
        return null
    }
}
