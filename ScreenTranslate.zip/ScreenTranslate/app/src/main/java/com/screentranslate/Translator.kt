package com.screentranslate

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Round-robin over enabled servers, automatic failover, 30s cooldown for a failing server. */
object Translator {
    private val cool = ConcurrentHashMap<String, Long>()
    private var rr = 0
    @Volatile var lastError = ""
    private val ALL = listOf("Google Translate", "Microsoft", "Gemini", "Groq", "OpenRouter")
    private val FREE = setOf("Google Translate", "Microsoft")
    private var msToken = ""
    private var msExp = 0L

    private fun http(url: String, body: String?, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 6000
        headers.forEach { c.setRequestProperty(it.key, it.value) }
        if (body != null) { c.requestMethod = "POST"; c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw Exception("HTTP $code" + if (url.contains("translate.googleapis")) "" else " " + s.take(80).replace("\n", " "))
        return s
    }

    private fun google(text: String, src: String): String {
        val sl = when (src) { "zh" -> "zh-CN"; "auto" -> "auto"; else -> src }
        val r = http("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=ar&dt=t&q=" + URLEncoder.encode(text, "UTF-8"), null)
        val a = JSONArray(r).getJSONArray(0)
        return (0 until a.length()).joinToString("") { a.getJSONArray(it).optString(0, "") }
    }

    private fun microsoft(text: String, src: String): String {
        val now = System.currentTimeMillis()
        if (now > msExp) { msToken = http("https://edge.microsoft.com/translate/auth", null, mapOf("User-Agent" to "Mozilla/5.0")).trim(); msExp = now + 8 * 60000 }
        val from = when (src) { "zh" -> "&from=zh-Hans"; "auto" -> ""; else -> "&from=$src" }
        val body = JSONArray().put(JSONObject().put("Text", text)).toString()
        val r = http("https://api-edge.cognitive.microsofttranslator.com/translate?api-version=3.0&to=ar$from", body,
            mapOf("Authorization" to "Bearer $msToken", "Content-Type" to "application/json", "User-Agent" to "Mozilla/5.0"))
        return JSONArray(r).getJSONObject(0).getJSONArray("translations").getJSONObject(0).getString("text")
    }

    private fun prompt(text: String) = "Translate this subtitle to Arabic. Output only the Arabic translation, nothing else:\n$text"

    private fun gemini(key: String, text: String): String {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt(text)))))).toString()
        val r = JSONObject(http("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key", body, mapOf("Content-Type" to "application/json")))
        return r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
    }

    private fun chat(url: String, key: String, model: String, text: String): String {
        val body = JSONObject().put("model", model).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt(text)))).toString()
        val r = JSONObject(http(url, body, mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key")))
        return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }

    private fun call(s: String, p: SharedPreferences, text: String, src: String): String {
        val k = p.getString("key_$s", "")!!.trim()
        return when (s) {
            "Microsoft" -> microsoft(text, src)
            "Gemini" -> gemini(k, text)
            "Groq" -> chat("https://api.groq.com/openai/v1/chat/completions", k, "llama-3.3-70b-versatile", text)
            "OpenRouter" -> chat("https://openrouter.ai/api/v1/chat/completions", k, "meta-llama/llama-3.3-70b-instruct:free", text)
            else -> google(text, src)
        }
    }

    fun translate(p: SharedPreferences, text: String): String? {
        val src = p.getString("src", "zh")!!
        val on = ALL.filter { val hasKey = p.getString("key_$it", "")!!.isNotBlank(); p.getBoolean("on_$it", it in FREE || hasKey) && (it in FREE || hasKey) }
            .ifEmpty { listOf("Google Translate") }
        val start = synchronized(this) { rr++ }
        val order = on.indices.map { on[(start + it) % on.size] }
        val now = System.currentTimeMillis()
        val errs = ArrayList<String>()
        val ready = order.filter { (cool[it] ?: 0L) < now }.ifEmpty { order }
        for (s in ready) {
            AppLog.add("→ $s")
            try { val r = call(s, p, text, src); if (r.isNotBlank()) { AppLog.add("✓ $s: ${r.take(40)}"); return r } }
            catch (e: Exception) { AppLog.add("✗ $s: ${e.message}"); errs.add("$s: ${e.message}"); cool[s] = now + (if (e.message?.contains("429") == true) 90000 else 30000) }
        }
        if ("Google Translate" !in ready) try { return google(text, src) } catch (e: Exception) { errs.add("Google Translate: ${e.message}") }
        lastError = errs.joinToString("  |  ")
        return null
    }
}
