package com.screentranslate

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Build
import android.media.projection.MediaProjectionManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.widget.doAfterTextChanged

class MainActivity : Activity() {
    private val p by lazy { getSharedPreferences("p", 0) }
    private var running = false
    private lateinit var status: TextView
    private lateinit var btn: TextView
    private lateinit var logTv: TextView
    private val h = Handler(Looper.getMainLooper())
    private val refresher = object : Runnable { override fun run() { if (::logTv.isInitialized) logTv.text = AppLog.text(); h.postDelayed(this, 1000) } }
    override fun onPause() { super.onPause(); h.removeCallbacks(refresher) }
    private fun hasPerm() = Settings.canDrawOverlays(this)
    override fun onResume() { super.onResume(); refresh(); h.post(refresher) }
    private fun refresh() { if (!::status.isInitialized) return
        if (::btn.isInitialized) btn.text = if (OverlayService.running) "■  إيقاف" else "▶  ابدأ الترجمة"
        status.text = if (hasPerm()) "✓ الصلاحية مفعلة" else "⚠ الصلاحية ناقصة: دوس هنا وفعّل «العرض فوق التطبيقات»"
        status.setTextColor(if (hasPerm()) 0xFF7DFFB0.toInt() else 0xFFFFC107.toInt()) }
    private fun openPerm() {
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        catch (e: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(0x26FFFFFF); setStroke(dp(1), 0x44FFFFFF) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
    }

    private fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == 1 && rc == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("rc", rc).putExtra("data", d)); btn.text = "■  إيقاف"
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF2B1B6B.toInt(), 0xFF0E1A4F.toInt())))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(48), dp(18), dp(24))
        }
        root.addView(label("Screen Translate", 28f, true))
        root.addView(label("ترجم أي لغة إلى العربية، مباشرة على الشاشة", 14f).apply { setPadding(0, 0, 0, dp(18)) })

        btn = TextView(this).apply {
            text = "▶  ابدأ الترجمة"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF2979FF.toInt())).apply { cornerRadius = dp(30).toFloat() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) }
        }
        btn.setOnClickListener {
            if (!hasPerm()) { Toast.makeText(this, "فعّل صلاحية العرض فوق التطبيقات أولا", Toast.LENGTH_LONG).show(); openPerm(); return@setOnClickListener }
            if (OverlayService.running) { startService(Intent(this, OverlayService::class.java).setAction("STOP")); btn.text = "▶  ابدأ الترجمة" }
            else startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        }
        root.addView(btn)
        status = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, dp(16)); gravity = Gravity.CENTER
            setOnClickListener { if (!hasPerm()) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } }
        root.addView(status); refresh()

        // Live log: shows what is happening (OCR text, server used, errors)
        val c4 = card(); c4.addView(label("السجل المباشر: شنو صاير توّا", 17f, true))
        logTv = TextView(this).apply {
            setTextColor(0xFFDDE6FF.toInt()); textSize = 12f; typeface = Typeface.MONOSPACE
            layoutDirection = View.LAYOUT_DIRECTION_LTR; setTextIsSelectable(true); text = "(فارغ: دوس ابدأ الترجمة)"
        }
        c4.addView(logTv)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        fun small(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0x33FFFFFF) }
            setOnClickListener { f() }; layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) }
        }
        row.addView(small("نسخ السجل") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", AppLog.all()))
            Toast.makeText(this, "تنسخ، الصقو في الشات", Toast.LENGTH_SHORT).show()
        })
        row.addView(small("مسح") { AppLog.clear(); logTv.text = "" })
        c4.addView(row); root.addView(c4)

        // Source language
        val c1 = card(); c1.addView(label("اللغة المصدر  ←  العربية", 17f, true))
        val langs = listOf("auto" to "تلقائي", "zh" to "中文 الصيني", "en" to "English", "ja" to "日本語", "ko" to "한국어")
        val rg = RadioGroup(this)
        langs.forEachIndexed { n, (code, name) ->
            rg.addView(RadioButton(this).apply { id = 100 + n; text = name; setTextColor(Color.WHITE); isChecked = p.getString("src", "zh") == code })
        }
        rg.setOnCheckedChangeListener { _, id -> p.edit().putString("src", langs[id - 100].first).apply() }
        c1.addView(rg); root.addView(c1)

        // Servers
        val c2 = card(); c2.addView(label("السيرفرات (بالترتيب عند الفشل)", 17f, true))
        listOf("Google Translate", "Microsoft", "Gemini", "Groq", "OpenRouter").forEach { s ->
            val sw = Switch(this).apply {
                text = s; setTextColor(Color.WHITE); isChecked = p.getBoolean("on_$s", s == "Google Translate" || s == "Microsoft")
                setOnCheckedChangeListener { _, v -> p.edit().putBoolean("on_$s", v).apply() }
            }
            c2.addView(sw)
            if (s != "Google Translate" && s != "Microsoft") c2.addView(EditText(this).apply {
                hint = "API key"; setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE); textSize = 13f
                setText(p.getString("key_$s", "")); doAfterTextChanged { p.edit().putString("key_$s", it.toString()).apply() }
            })
        }
        root.addView(c2)

        // Appearance
        val c3 = card(); c3.addView(label("حجم خط الترجمة", 17f, true))
        c3.addView(SeekBar(this).apply {
            max = 18; progress = p.getInt("font", 20) - 14
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("font", v + 14).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(c3)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
