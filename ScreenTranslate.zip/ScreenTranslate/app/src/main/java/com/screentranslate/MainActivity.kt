package com.screentranslate

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.widget.doAfterTextChanged

class MainActivity : Activity() {
    private val p by lazy { getSharedPreferences("p", 0) }
    private var running = false
    private lateinit var status: TextView
    private fun hasPerm() = Settings.canDrawOverlays(this)
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() { if (!::status.isInitialized) return
        status.text = if (hasPerm()) "✓ الصلاحية مفعلة" else "⚠ الصلاحية ناقصة: دوس هنا وفعّل «العرض فوق التطبيقات»"
        status.setTextColor(if (hasPerm()) 0xFF7DFFB0.toInt() else 0xFFFFC107.toInt()) }
    private fun openPerm() {
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        catch (e: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16))
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(0x26FFFFFF); setStroke(dp(1), 0x44FFFFFF) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
    }

    private fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF2B1B6B.toInt(), 0xFF0E1A4F.toInt())))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(48), dp(18), dp(24))
        }
        root.addView(label("Screen Translate", 28f, true))
        root.addView(label("ترجم أي لغة إلى العربية، مباشرة على الشاشة", 14f).apply { setPadding(0, 0, 0, dp(18)) })

        val btn = TextView(this).apply {
            text = "▶  ابدأ الترجمة"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF7C4DFF.toInt(), 0xFF2979FF.toInt())).apply { cornerRadius = dp(30).toFloat() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) }
        }
        btn.setOnClickListener {
            if (!hasPerm()) { Toast.makeText(this, "فعّل صلاحية العرض فوق التطبيقات أولا", Toast.LENGTH_LONG).show(); openPerm(); return@setOnClickListener }
            val i = Intent(this, OverlayService::class.java)
            if (running) i.action = "STOP"
            startService(i); running = !running
            btn.text = if (running) "■  إيقاف" else "▶  ابدأ الترجمة"
        }
        root.addView(btn)
        status = TextView(this).apply { textSize = 14f; setPadding(0, 0, 0, dp(16)); gravity = Gravity.CENTER
            setOnClickListener { if (!hasPerm()) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } }
        root.addView(status); refresh()

        // Source language
        val c1 = card(); c1.addView(label("اللغة المصدر  ←  العربية", 17f, true))
        val langs = listOf("auto" to "تلقائي", "zh" to "中文 الصيني", "en" to "English", "ja" to "日本語", "ko" to "한국어")
        val rg = RadioGroup(this)
        langs.forEachIndexed { n, (code, name) ->
            rg.addView(RadioButton(this).apply { id = 100 + n; text = name; setTextColor(Color.WHITE); isChecked = p.getString("src", "zh") == code })
        }
        rg.setOnCheckedChangeListener { _, id -> p.edit().putString("src", langs[id - 100].first).apply() }
        c1.addView(rg); root.addView(c1)

        // Servers
        val c2 = card(); c2.addView(label("السيرفرات (بالترتيب عند الفشل)", 17f, true))
        listOf("Google Translate", "Gemini", "Groq", "OpenRouter").forEach { s ->
            val sw = Switch(this).apply {
                text = s; setTextColor(Color.WHITE); isChecked = p.getBoolean("on_$s", s == "Google Translate")
                setOnCheckedChangeListener { _, v -> p.edit().putBoolean("on_$s", v).apply() }
            }
            c2.addView(sw)
            if (s != "Google Translate") c2.addView(EditText(this).apply {
                hint = "API key"; setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE); textSize = 13f
                setText(p.getString("key_$s", "")); doAfterTextChanged { p.edit().putString("key_$s", it.toString()).apply() }
            })
        }
        root.addView(c2)

        // Appearance
        val c3 = card(); c3.addView(label("حجم خط الترجمة", 17f, true))
        c3.addView(SeekBar(this).apply {
            max = 18; progress = p.getInt("font", 20) - 14
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("font", v + 14).apply() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(c3)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
