package com.screentranslate

import android.app.*
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import android.content.Intent
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val p by lazy { getSharedPreferences("p", 0) }
    private var zone: View? = null
    private var bar: TextView? = null
    private var fab: TextView? = null
    private lateinit var zp: LP
    private lateinit var bp: LP
    private lateinit var fp: LP
    private var working = false   // false = paused/editing (everything visible), true = translating (box transparent, button docked right)
    private var handleV: View? = null
    private val HINT = "حط المربع فوق السوس تيتر، وبعدها دوس الزر العايم 译 باش تبدا"
    private val handler = Handler(Looper.getMainLooper())
    private var proj: MediaProjection? = null
    private var vd: android.hardware.display.VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val recs = HashMap<String, TextRecognizer>()
    private val pool = Executors.newFixedThreadPool(4)
    private val cache = java.util.Collections.synchronizedMap(HashMap<String, String>())
    @Volatile private var seq = 0
    private var shownSeq = 0
    private var lastText = ""
    private var empty = 0
    private var noFrame = 0
    private var everRead = false
    private fun dbg(m: String) { AppLog.add(m); bar?.text = m; bar?.alpha = 1f }

    companion object { @Volatile var running = false }

    // separate saved positions for portrait ("p") and landscape ("l")
    private val o get() = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "l" else "p"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (i == null || data == null) { stopSelf(); return START_NOT_STICKY }
        if (zone == null) { startFg(); show(); startCapture(i.getIntExtra("rc", 0), data) }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (zone != null) { layoutAll(); try { resizeCapture() } catch (_: Exception) {} }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int) =
        LP(w, h, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START }

    private fun touch(move: (Int, Int) -> Unit, tap: (() -> Unit)? = null, long: (() -> Unit)? = null): View.OnTouchListener {
        var lx = 0f; var ly = 0f; var sx = 0f; var sy = 0f; var t = 0L
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; sx = lx; sy = ly; t = e.eventTime }
                MotionEvent.ACTION_MOVE -> { move((e.rawX - lx).toInt(), (e.rawY - ly).toInt()); lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_UP -> {
                    save()
                    if (abs(e.rawX - sx) + abs(e.rawY - sy) < dp(8)) {
                        if (e.eventTime - t > 700) long?.invoke() else tap?.invoke()
                    }
                }
            }
            true
        }
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        zp = lp(0, 0); bp = lp(0, LP.WRAP_CONTENT); fp = lp(dp(56), dp(56))
        bp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL   // bar always centered

        val z = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(2), 0xFF7C4DFF.toInt(), dp(8).toFloat(), dp(5).toFloat())
                cornerRadius = dp(10).toFloat()
            }
            setOnTouchListener(touch({ dx, dy -> zp.x += dx; zp.y += dy; wm.updateViewLayout(this, zp) }))
        }
        val h = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2979FF.toInt()) }
            setOnTouchListener(touch({ dx, dy ->
                zp.width = (zp.width + dx).coerceAtLeast(dp(80)); zp.height = (zp.height + dy).coerceAtLeast(dp(40))
                wm.updateViewLayout(z, zp)
            }))
        }
        z.addView(h, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END)); handleV = h

        val b = TextView(this).apply {
            text = HINT; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            textSize = p.getInt("font", 20).toFloat(); setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xCC140F3C.toInt()) }
            setOnTouchListener(touch({ _, dy -> bp.y += dy; wm.updateViewLayout(this, bp) }))   // vertical only
        }

        // Floating button: tap = start/pause translation, long press = stop service, drag = move
        val f = TextView(this).apply {
            text = "译"; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C4DFF.toInt(), 0xFF2979FF.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            setOnTouchListener(touch({ dx, dy -> if (!working) fp.x += dx; fp.y += dy; wm.updateViewLayout(this, fp) },
                tap = { toggle() }, long = { stopSelf() }))
        }
        zone = z; bar = b; fab = f
        layoutAll()
        wm.addView(z, zp); wm.addView(b, bp); wm.addView(f, fp)
    }

    private fun layoutAll() {
        val dm = resources.displayMetrics
        zp.width = p.getInt("zw_$o", dm.widthPixels * 7 / 10); zp.height = p.getInt("zh_$o", dp(90))
        zp.x = p.getInt("zx_$o", (dm.widthPixels - zp.width) / 2); zp.y = p.getInt("zy_$o", dm.heightPixels * 7 / 10)
        bp.width = dm.widthPixels * 92 / 100; bp.x = 0; bp.y = p.getInt("by_$o", dm.heightPixels / 4)
        fp.x = if (working) dm.widthPixels - dp(28) else p.getInt("fx_$o", dm.widthPixels - dp(64)); fp.y = p.getInt("fy_$o", dm.heightPixels / 2)
        zone?.let { try { wm.updateViewLayout(it, zp) } catch (_: Exception) {} }
        bar?.let { try { wm.updateViewLayout(it, bp) } catch (_: Exception) {} }
        fab?.let { try { wm.updateViewLayout(it, fp) } catch (_: Exception) {} }
    }

    private fun toggle() {
        working = !working
        AppLog.add(if (working) "▶ الترجمة تخدم" else "⏸ واقفة")
        applyState()
    }

    // paused: box + handle + bar visible, button opaque. working: box almost invisible and click-through, button faded and docked on the right edge
    private fun applyState() {
        zone?.alpha = if (working) 0.12f else 1f
        handleV?.visibility = if (working) View.GONE else View.VISIBLE
        zp.flags = if (working) zp.flags or LP.FLAG_NOT_TOUCHABLE else zp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        fab?.alpha = if (working) 0.45f else 1f
        bar?.let { if (working) it.alpha = 0f else { it.text = HINT; it.alpha = 1f } }
        if (working) { lastText = ""; empty = 0 }
        layoutAll()
    }

    private fun save() {
        p.edit().putInt("zx_$o", zp.x).putInt("zy_$o", zp.y).putInt("zw_$o", zp.width).putInt("zh_$o", zp.height)
            .putInt("by_$o", bp.y).putInt("fy_$o", fp.y).apply { if (!working) putInt("fx_$o", fp.x) }.apply()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("st", "Screen Translate", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "st").setContentTitle("Screen Translate").setContentText("الترجمة تخدم")
            .setSmallIcon(android.R.drawable.ic_menu_edit).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
        running = true
    }

    private fun screenSize(): Pair<Int, Int> {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) return w.currentWindowMetrics.bounds.let { it.width() to it.height() }
        val dm = DisplayMetrics(); @Suppress("DEPRECATION") w.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun startCapture(rc: Int, data: Intent) {
        val pr = getSystemService(MediaProjectionManager::class.java).getMediaProjection(rc, data)
        pr.registerCallback(object : MediaProjection.Callback() { override fun onStop() { handler.post { stopSelf() } } }, handler)
        proj = pr
        val (w, h) = screenSize()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2); reader = r
        vd = pr.createVirtualDisplay("st", w, h, resources.displayMetrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        AppLog.add("التصوير بدا ${w}x$h")
        handler.postDelayed(tick, 1000)
    }

    private fun resizeCapture() {
        val (w, h) = screenSize(); val old = reader
        val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.resize(w, h, resources.displayMetrics.densityDpi); vd?.setSurface(nr.surface)
        reader = nr; old?.close()
    }

    private val tick = object : Runnable {
        override fun run() { try { capture() } catch (_: Exception) {}; handler.postDelayed(this, 1000) }
    }

    private fun rec(src: String) = recs.getOrPut(src) {
        TextRecognition.getClient(when (src) {
            "en" -> TextRecognizerOptions.DEFAULT_OPTIONS
            "ja" -> JapaneseTextRecognizerOptions.Builder().build()
            "ko" -> KoreanTextRecognizerOptions.Builder().build()
            else -> ChineseTextRecognizerOptions.Builder().build()
        })
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val pl = img.planes[0]
            val full = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(pl.buffer)
            val ins = dp(5)
            val l = (zp.x + ins).coerceIn(0, img.width - 1); val t = (zp.y + ins).coerceIn(0, img.height - 1)
            val w = (zp.width - 2 * ins).coerceAtMost(img.width - l).coerceAtLeast(1)
            val h = (zp.height - 2 * ins).coerceAtMost(img.height - t).coerceAtLeast(1)
            return Bitmap.createBitmap(full, l, t, w, h)
        } finally { img.close() }
    }

    private fun capture() {
        if (!working) return
        val bmp = grab()
        if (bmp == null) { if (++noFrame == 5) AppLog.add("لا صورة جديدة (الشاشة ثابتة)"); return }
        noFrame = 0
        val r = rec(p.getString("src", "zh")!!)
        r.process(InputImage.fromBitmap(binarize(bmp), 0)).addOnSuccessListener { res ->
            if (res.text.isBlank()) r.process(InputImage.fromBitmap(bmp, 0)).addOnSuccessListener { onText(it.text) }.addOnFailureListener { onText("") }
            else onText(res.text)
        }.addOnFailureListener { dbg("⚠ OCR: ${it.message}") }
    }

    // Keep only near-white pixels (subtitle fill) -> black text on white: removes busy video background before OCR
    private fun binarize(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val mn = minOf((c shr 16) and 255, (c shr 8) and 255, c and 255)
            px[i] = if (mn > 180) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); o.setPixels(px, 0, w, 0, 0, w, h)
        return if (h < 120) Bitmap.createScaledBitmap(o, w * 2, h * 2, true) else o
    }

    // OCR reads the same subtitle slightly differently each second: treat near-identical texts as the same
    private fun similar(a: String, b: String): Boolean {
        val x = a.filter { it.isLetterOrDigit() }.take(120); val y = b.filter { it.isLetterOrDigit() }.take(120)
        if (x == y) return true
        val m = maxOf(x.length, y.length)
        if (m == 0 || abs(x.length - y.length) > m / 3) return false
        var prev = IntArray(y.length + 1) { it }
        for (i in 1..x.length) {
            val cur = IntArray(y.length + 1); cur[0] = i
            for (j in 1..y.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (x[i - 1] == y[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[y.length] <= m * 3 / 10
    }

    private fun onText(raw: String) {
        val t0 = raw.replace("\n", " ").trim()
        val cjk = t0.count { it.code in 0x3040..0x9FFF || it.code in 0xAC00..0xD7AF }
        val t = if (p.getString("src", "zh") != "en" && cjk < 2) "" else t0   // ignore OCR garbage without CJK text
        if (t.isEmpty()) {
            empty++
            if (empty == 3) { AppLog.add("OCR: فارغ (ما فماش نص)"); lastText = ""; if (everRead) bar?.alpha = 0f }
            if (empty == 8 && !everRead) dbg("⚠ ما لقيتش نص في المربع: حط المربع فوق السوس تيتر")
            return
        }
        empty = 0; everRead = true
        if (t.length < 2 || similar(t, lastText)) return
        lastText = t
        AppLog.add("OCR: «${t.take(40)}»")
        cache[t]?.let { bar?.text = it; bar?.alpha = 1f; return }
        val id = ++seq
        pool.execute {
            val tr = Translator.translate(p, t)
            if (tr == null) { handler.post { dbg("⚠ فشلت الترجمة: ${Translator.lastError}") }; return@execute }
            cache[t] = tr
            handler.post { if (id >= shownSeq) { shownSeq = id; bar?.text = tr; bar?.alpha = 1f } }
        }
    }

    override fun onDestroy() {
        running = false
        AppLog.add("الخدمة توقفت")
        handler.removeCallbacksAndMessages(null)
        try { vd?.release(); reader?.close(); proj?.stop() } catch (_: Exception) {}
        listOf(zone, bar, fab).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        super.onDestroy()
    }
}
