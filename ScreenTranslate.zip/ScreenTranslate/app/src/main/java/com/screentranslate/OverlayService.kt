package com.screentranslate

import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val p by lazy { getSharedPreferences("p", 0) }
    private var zone: View? = null
    private var bar: TextView? = null
    private var fab: TextView? = null
    private lateinit var zp: LP
    private lateinit var bp: LP
    private lateinit var fp: LP
    private var shown = true

    // separate saved positions for portrait ("p") and landscape ("l")
    private val o get() = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "l" else "p"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (zone == null) show()
        return START_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (zone != null) layoutAll()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int) =
        LP(w, h, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START }

    private fun touch(move: (Int, Int) -> Unit, tap: (() -> Unit)? = null, long: (() -> Unit)? = null): View.OnTouchListener {
        var lx = 0f; var ly = 0f; var sx = 0f; var sy = 0f; var t = 0L
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; sx = lx; sy = ly; t = e.eventTime }
                MotionEvent.ACTION_MOVE -> { move((e.rawX - lx).toInt(), (e.rawY - ly).toInt()); lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_UP -> {
                    save()
                    if (abs(e.rawX - sx) + abs(e.rawY - sy) < dp(8)) {
                        if (e.eventTime - t > 700) long?.invoke() else tap?.invoke()
                    }
                }
            }
            true
        }
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        zp = lp(0, 0); bp = lp(0, LP.WRAP_CONTENT); fp = lp(dp(56), dp(56))
        bp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL   // bar always centered

        val z = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(2), 0xFF7C4DFF.toInt(), dp(8).toFloat(), dp(5).toFloat())
                cornerRadius = dp(10).toFloat(); setColor(0x1A7C4DFF)
            }
            setOnTouchListener(touch({ dx, dy -> zp.x += dx; zp.y += dy; wm.updateViewLayout(this, zp) }))
        }
        val h = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2979FF.toInt()) }
            setOnTouchListener(touch({ dx, dy ->
                zp.width = (zp.width + dx).coerceAtLeast(dp(80)); zp.height = (zp.height + dy).coerceAtLeast(dp(40))
                wm.updateViewLayout(z, zp)
            }))
        }
        z.addView(h, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END))

        val b = TextView(this).apply {
            text = "هنا تظهر الترجمة"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            textSize = p.getInt("font", 20).toFloat(); setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xCC140F3C.toInt()) }
            setOnTouchListener(touch({ _, dy -> bp.y += dy; wm.updateViewLayout(this, bp) }))   // vertical only
        }

        // Floating button: tap = show/hide zone+bar, long press = stop, drag = move
        val f = TextView(this).apply {
            text = "译"; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C4DFF.toInt(), 0xFF2979FF.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            setOnTouchListener(touch({ dx, dy -> fp.x += dx; fp.y += dy; wm.updateViewLayout(this, fp) },
                tap = { toggle() }, long = { stopSelf() }))
        }
        zone = z; bar = b; fab = f
        layoutAll()
        wm.addView(z, zp); wm.addView(b, bp); wm.addView(f, fp)
    }

    private fun layoutAll() {
        val dm = resources.displayMetrics
        zp.width = p.getInt("zw_$o", dm.widthPixels * 7 / 10); zp.height = p.getInt("zh_$o", dp(90))
        zp.x = p.getInt("zx_$o", (dm.widthPixels - zp.width) / 2); zp.y = p.getInt("zy_$o", dm.heightPixels * 7 / 10)
        bp.width = dm.widthPixels * 92 / 100; bp.x = 0; bp.y = p.getInt("by_$o", dm.heightPixels / 4)
        fp.x = p.getInt("fx_$o", dm.widthPixels - dp(64)); fp.y = p.getInt("fy_$o", dm.heightPixels / 2)
        zone?.let { try { wm.updateViewLayout(it, zp) } catch (_: Exception) {} }
        bar?.let { try { wm.updateViewLayout(it, bp) } catch (_: Exception) {} }
        fab?.let { try { wm.updateViewLayout(it, fp) } catch (_: Exception) {} }
    }

    private fun toggle() {
        shown = !shown
        val v = if (shown) View.VISIBLE else View.GONE
        zone?.visibility = v; bar?.visibility = v
        fab?.alpha = if (shown) 1f else 0.5f
    }

    private fun save() {
        p.edit().putInt("zx_$o", zp.x).putInt("zy_$o", zp.y).putInt("zw_$o", zp.width).putInt("zh_$o", zp.height)
            .putInt("by_$o", bp.y).putInt("fx_$o", fp.x).putInt("fy_$o", fp.y).apply()
    }

    override fun onDestroy() {
        listOf(zone, bar, fab).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        super.onDestroy()
    }
}
