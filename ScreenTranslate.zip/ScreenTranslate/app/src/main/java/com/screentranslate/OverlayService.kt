package com.screentranslate

import android.app.*
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import android.content.Intent
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.WindowManager.LayoutParams as LP
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val p by lazy { getSharedPreferences("p", 0) }
    private var zone: View? = null
    private var bar: TextView? = null
    private var fab: TextView? = null
    private lateinit var zp: LP
    private lateinit var bp: LP
    private lateinit var fp: LP
    private var working = false   // false = paused/editing (everything visible), true = translating (box transparent, button docked right)
    private var handleV: View? = null
    private var grip: View? = null   // small vertical drag handle for the translation bar
    private lateinit var gp: LP
    // full-page mode: second button "页" translates every text block on the screen and paints the translation over it
    private var pageFab: TextView? = null
    private var pageLayer: FrameLayout? = null
    private lateinit var pp: LP
    private lateinit var lpg: LP
    private var pageShown = false
    private var pageBusy = false
    private var lastImgW = 0
    private var lastImgH = 0
    private class PB(val r: Rect, val lines: Int)
    private val HINT = "حط المربع فوق السوس تيتر، وبعدها دوس الزر العايم 译 باش تبدا"
    private val handler = Handler(Looper.getMainLooper())
    private var proj: MediaProjection? = null
    private var vd: android.hardware.display.VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val recs = HashMap<String, TextRecognizer>()
    private val pool = Executors.newFixedThreadPool(4)
    @Volatile private var seq = 0
    private var shownSeq = 0
    private var lastText = ""
    private var empty = 0
    private var noFrame = 0
    private var everRead = false
    // event-driven capture: fast cheap polling + change detection, OCR only when the subtitle changed and is stable
    private var busy = false
    private var busySince = 0L
    private var dirty = false
    private var recheck = true
    private var lastOcrAt = 0L
    private var lastSig: IntArray? = null
    private var lastBmp: Bitmap? = null
    private var lastBin: Bitmap? = null
    private var fullBmp: Bitmap? = null
    private fun dbg(m: String) { AppLog.add(m); bar?.text = m; bar?.alpha = 1f }

    companion object { @Volatile var running = false }

    // separate saved positions for portrait ("p") and landscape ("l")
    private val o get() = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "l" else "p"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP" || i?.action == "STOP_EXIT") {
            if (i?.action == "STOP_EXIT") sendBroadcast(Intent("com.screentranslate.EXIT").setPackage(packageName))   // also closes the app screen
            stopSelf(); return START_NOT_STICKY
        }
        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (i == null || data == null) { stopSelf(); return START_NOT_STICKY }
        if (zone == null) { TranslationCache.init(this); startFg(); show(); startCapture(i.getIntExtra("rc", 0), data) }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (zone != null) { clearPage(); layoutAll(); try { resizeCapture() } catch (_: Exception) {} }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int) =
        LP(w, h, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START }

    private fun touch(move: (Int, Int) -> Unit, tap: (() -> Unit)? = null, long: (() -> Unit)? = null): View.OnTouchListener {
        var lx = 0f; var ly = 0f; var sx = 0f; var sy = 0f; var t = 0L
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; sx = lx; sy = ly; t = e.eventTime }
                MotionEvent.ACTION_MOVE -> { move((e.rawX - lx).toInt(), (e.rawY - ly).toInt()); lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_UP -> {
                    save()
                    if (abs(e.rawX - sx) + abs(e.rawY - sy) < dp(8)) {
                        if (e.eventTime - t > 700) long?.invoke() else tap?.invoke()
                    }
                }
            }
            true
        }
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        zp = lp(0, 0); bp = lp(0, LP.WRAP_CONTENT).apply { flags = flags or LP.FLAG_NOT_TOUCHABLE }; fp = lp(dp(56), dp(56)); gp = lp(dp(34), dp(56)); pp = lp(dp(48), dp(48))
        lpg = lp(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels).apply { flags = flags or LP.FLAG_NOT_TOUCHABLE; x = 0; y = 0 }
        bp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL   // bar always centered

        val z = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(2), 0xFF7C4DFF.toInt(), dp(8).toFloat(), dp(5).toFloat())
                cornerRadius = dp(10).toFloat()
            }
            setOnTouchListener(touch({ _, dy -> zp.y += dy; wm.updateViewLayout(this, zp) }))   // vertical only
        }
        val h = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2979FF.toInt()) }
            setOnTouchListener(touch({ dx, dy ->
                zp.width = (zp.width + dx).coerceAtLeast(dp(80)); zp.height = (zp.height + dy).coerceAtLeast(dp(40))
                wm.updateViewLayout(z, zp)
            }))
        }
        z.addView(h, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END)); handleV = h

        val b = OutlinedText(this).apply {
            text = HINT; setTextColor(0xFFFFEB3B.toInt()); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            textSize = p.getInt("font", 20).toFloat(); setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(0x33000000)
        }

        // Floating button: tap = start/pause translation, long press = stop service, drag = move
        val f = TextView(this).apply {
            text = "译"; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF7C4DFF.toInt(), 0xFF2979FF.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            setOnTouchListener(touch({ dx, dy -> if (!working) fp.x += dx; fp.y += dy; wm.updateViewLayout(this, fp); placePage() },
                tap = { toggle() }, long = { stopSelf() }))
        }
        // The bar itself is click-through (so seeking/pausing the video works under it); only this small grip moves it, vertically
        val g = TextView(this).apply {
            text = "⇕"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0xAA7C4DFF.toInt()) }
            setOnTouchListener(touch({ _, dy -> bp.y += dy; bar?.let { wm.updateViewLayout(it, bp) }; gp.y = bp.y; wm.updateViewLayout(this, gp) }))
        }
        val pf = TextView(this).apply {
            text = "页"; setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF2979FF.toInt(), 0xFF7C4DFF.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            setOnTouchListener(touch({ _, _ -> }, tap = { pageToggle() }))
        }
        val pl = FrameLayout(this)
        zone = z; bar = b; fab = f; grip = g; pageFab = pf; pageLayer = pl
        layoutAll()
        wm.addView(pl, lpg); wm.addView(z, zp); wm.addView(b, bp); wm.addView(g, gp); wm.addView(f, fp); wm.addView(pf, pp)
    }

    private fun layoutAll() {
        val dm = resources.displayMetrics
        zp.width = p.getInt("zw_$o", dm.widthPixels * 7 / 10); zp.height = p.getInt("zh_$o", dp(90))
        zp.x = p.getInt("zx_$o", (dm.widthPixels - zp.width) / 2); zp.y = p.getInt("zy_$o", dm.heightPixels * 7 / 10)
        bp.width = dm.widthPixels * 92 / 100; bp.x = 0; bp.y = p.getInt("by_$o", dm.heightPixels / 4)
        fp.x = if (working) dm.widthPixels - dp(28) else p.getInt("fx_$o", dm.widthPixels - dp(64)); fp.y = p.getInt("fy_$o", dm.heightPixels / 2)
        lpg.width = dm.widthPixels; lpg.height = dm.heightPixels
        pageLayer?.let { try { wm.updateViewLayout(it, lpg) } catch (_: Exception) {} }
        gp.gravity = Gravity.TOP or Gravity.START; gp.x = 0; gp.y = bp.y
        grip?.let { try { wm.updateViewLayout(it, gp) } catch (_: Exception) {} }
        zone?.let { try { wm.updateViewLayout(it, zp) } catch (_: Exception) {} }
        bar?.let { try { wm.updateViewLayout(it, bp) } catch (_: Exception) {} }
        fab?.let { try { wm.updateViewLayout(it, fp) } catch (_: Exception) {} }
        placePage()
    }

    private fun placePage() {
        pp.x = fp.x + dp(4); pp.y = fp.y + dp(60)
        pageFab?.let { try { wm.updateViewLayout(it, pp) } catch (_: Exception) {} }
    }

    private fun toggle() {
        working = !working
        AppLog.add(if (working) "▶ الترجمة تخدم" else "⏸ واقفة")
        applyState()
    }

    // paused: box + handle + bar visible, button opaque. working: box almost invisible and click-through, button faded and docked on the right edge
    private fun applyState() {
        zone?.alpha = if (working) 0.12f else 1f
        handleV?.visibility = if (working) View.GONE else View.VISIBLE
        zp.flags = if (working) zp.flags or LP.FLAG_NOT_TOUCHABLE else zp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        fab?.alpha = if (working) 0.45f else 1f
        grip?.alpha = if (working) 0.4f else 1f
        bar?.let { it.setBackgroundColor(if (working) 0 else 0x33000000); if (working) it.alpha = 0f else { it.text = HINT; it.alpha = 1f } }
        if (working) { lastText = ""; empty = 0; lastSig = null; dirty = false; recheck = true; busy = false }
        layoutAll()
    }

    private fun save() {
        p.edit().putInt("zx_$o", zp.x).putInt("zy_$o", zp.y).putInt("zw_$o", zp.width).putInt("zh_$o", zp.height)
            .putInt("by_$o", bp.y).putInt("fy_$o", fp.y).apply { if (!working) putInt("fx_$o", fp.x) }.apply()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("st", "Screen Translate", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction("STOP_EXIT"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val openPi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopAction = Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "إيقاف وإغلاق", stopPi).build()
        val n = Notification.Builder(this, "st").setContentTitle("Screen Translate").setContentText("الترجمة تخدم")
            .setSmallIcon(android.R.drawable.ic_menu_edit).setContentIntent(openPi).addAction(stopAction).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
        running = true
    }

    private fun screenSize(): Pair<Int, Int> {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) return w.currentWindowMetrics.bounds.let { it.width() to it.height() }
        val dm = DisplayMetrics(); @Suppress("DEPRECATION") w.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private var capVisible = true
    private fun setCapVisible(v: Boolean) {
        if (v == capVisible) return
        capVisible = v
        AppLog.add(if (v) "👁 رجعت للتطبيق: الترجمة ترجع" else "👁 خرجت من التطبيق: الترجمة تستنى")
        listOf(zone, bar, fab, grip, pageFab, pageLayer).forEach { it?.visibility = if (v) View.VISIBLE else View.INVISIBLE }
        lastSig = null; dirty = false; recheck = v
    }

    private fun startCapture(rc: Int, data: Intent) {
        val pr = getSystemService(MediaProjectionManager::class.java).getMediaProjection(rc, data)
        pr.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { AppLog.add("⛔ النظام أوقف التصوير (MediaProjection)"); handler.post { stopSelf() } }
            // Android 14+ "share one app": called when the captured app is hidden (you left it) or visible again (you came back)
            override fun onCapturedContentVisibilityChanged(isVisible: Boolean) { handler.post { setCapVisible(isVisible) } }
        }, handler)
        proj = pr
        val (w, h) = screenSize()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2); reader = r
        vd = pr.createVirtualDisplay("st", w, h, resources.displayMetrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        AppLog.add("التصوير بدا ${w}x$h")
        handler.postDelayed(tick, 1000)
    }

    private fun resizeCapture() {
        val (w, h) = screenSize(); val old = reader
        val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.resize(w, h, resources.displayMetrics.densityDpi); vd?.setSurface(nr.surface)
        reader = nr; old?.close(); fullBmp = null
    }

    private val tick = object : Runnable {
        override fun run() { try { capture() } catch (_: Exception) {}; handler.postDelayed(this, 200) }
    }

    private fun rec(src: String) = recs.getOrPut(src) {
        TextRecognition.getClient(when (src) {
            "en" -> TextRecognizerOptions.DEFAULT_OPTIONS
            "ja" -> JapaneseTextRecognizerOptions.Builder().build()
            "ko" -> KoreanTextRecognizerOptions.Builder().build()
            else -> ChineseTextRecognizerOptions.Builder().build()
        })
    }

    private fun fillFull(img: android.media.Image): Bitmap {
        val pl = img.planes[0]
        val fw = pl.rowStride / pl.pixelStride
        var full = fullBmp
        if (full == null || full.width != fw || full.height != img.height) { full = Bitmap.createBitmap(fw, img.height, Bitmap.Config.ARGB_8888); fullBmp = full }
        full!!.copyPixelsFromBuffer(pl.buffer)
        lastImgW = img.width; lastImgH = img.height
        return full
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val full = fillFull(img)
            val ins = dp(5)
            val l = (zp.x + ins).coerceIn(0, img.width - 1); val t = (zp.y + ins).coerceIn(0, img.height - 1)
            val w = (zp.width - 2 * ins).coerceAtMost(img.width - l).coerceAtLeast(1)
            val h = (zp.height - 2 * ins).coerceAtMost(img.height - t).coerceAtLeast(1)
            return Bitmap.createBitmap(full, l, t, w, h)
        } finally { img.close() }
    }

    // whole screen (our own overlays are hidden by the caller); falls back to the last frame if the screen did not change
    private fun grabFull(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) { try { fillFull(img) } finally { img.close() } }
        val full = fullBmp ?: return null
        if (lastImgW <= 0 || lastImgH <= 0) return null
        return Bitmap.createBitmap(full, 0, 0, lastImgW.coerceAtMost(full.width), lastImgH.coerceAtMost(full.height))
    }

    // tiny 24x6 grayscale thumbnail of the subtitle mask: cheap to compare
    private fun sig(bin: Bitmap): IntArray {
        val t = Bitmap.createScaledBitmap(bin, 24, 6, true)
        val px = IntArray(24 * 6); t.getPixels(px, 0, 24, 0, 0, 24, 6); t.recycle()
        return IntArray(px.size) { (px[it] shr 8) and 255 }
    }

    private fun capture() {
        if (!working || !capVisible) return
        val now = SystemClock.uptimeMillis()
        if (busy) { if (now - busySince < 3000) return else busy = false }
        val fresh = grab()
        val bmp: Bitmap; val bin: Bitmap
        if (fresh != null) {
            noFrame = 0
            bmp = fresh; bin = binarize(fresh)
            val s = sig(bin); val prev = lastSig; lastSig = s
            lastBmp = bmp; lastBin = bin
            if (prev == null || s.indices.sumOf { abs(s[it] - prev[it]) } > 500) { dirty = true; return }   // changed: wait for one stable frame (fade-in)
        } else {
            if (++noFrame == 5) AppLog.add("لا صورة جديدة (الشاشة ثابتة)")
            bmp = lastBmp ?: return; bin = lastBin ?: return   // static screen: the last frame is the stable one
        }
        if (!(dirty || recheck || now - lastOcrAt > 3000)) return
        dirty = false; recheck = false; lastOcrAt = now; busy = true; busySince = now
        val r = rec(p.getString("src", "zh")!!)
        r.process(InputImage.fromBitmap(bin, 0)).addOnSuccessListener { res ->
            if (res.text.isBlank()) r.process(InputImage.fromBitmap(bmp, 0)).addOnSuccessListener { busy = false; onText(it.text) }.addOnFailureListener { busy = false; onText("") }
            else { busy = false; onText(res.text) }
        }.addOnFailureListener { busy = false; dbg("⚠ OCR: ${it.message}") }
    }

    // Keep only near-white pixels (subtitle fill) -> black text on white: removes busy video background before OCR
    private fun binarize(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val mn = minOf((c shr 16) and 255, (c shr 8) and 255, c and 255)
            px[i] = if (mn > 180) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
        val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); o.setPixels(px, 0, w, 0, 0, w, h)
        return if (h < 120) Bitmap.createScaledBitmap(o, w * 2, h * 2, true) else o
    }

    // OCR reads the same subtitle slightly differently each second: treat near-identical texts as the same
    private fun similar(a: String, b: String): Boolean {
        val x = a.filter { it.isLetterOrDigit() }.take(120); val y = b.filter { it.isLetterOrDigit() }.take(120)
        if (x == y) return true
        val m = maxOf(x.length, y.length)
        if (m == 0 || abs(x.length - y.length) > m / 3) return false
        var prev = IntArray(y.length + 1) { it }
        for (i in 1..x.length) {
            val cur = IntArray(y.length + 1); cur[0] = i
            for (j in 1..y.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (x[i - 1] == y[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[y.length] <= m * 3 / 10
    }

    private fun onText(raw: String) {
        val t0 = raw.replace("\n", " ").trim()
        val cjk = t0.count { it.code in 0x3040..0x9FFF || it.code in 0xAC00..0xD7AF }
        val t = if (p.getString("src", "zh") != "en" && cjk < 2) "" else t0   // ignore OCR garbage without CJK text
        if (t.isEmpty()) {
            empty++
            if (empty < 2) recheck = true
            if (empty == 2) { AppLog.add("OCR: فارغ (ما فماش نص)"); lastText = ""; if (everRead) bar?.alpha = 0f }
            if (empty == 3 && !everRead) dbg("⚠ ما لقيتش نص في المربع: حط المربع فوق السوس تيتر")
            return
        }
        empty = 0; everRead = true
        if (t.length < 2 || similar(t, lastText)) return
        lastText = t
        AppLog.add("OCR: «${t.take(40)}»")
        val src = p.getString("src", "zh")!!
        val id = ++seq
        TranslationCache.get(src, t)?.let { shownSeq = id; AppLog.add("💾 من الكاش"); bar?.text = it; bar?.alpha = 1f; return }
        pool.execute {
            TranslationCache.getSimilar(src, t)?.let { hit ->
                AppLog.add("💾 من الكاش (جملة مشابهة)")
                handler.post { if (id >= shownSeq) { shownSeq = id; bar?.text = hit; bar?.alpha = 1f } }
                return@execute
            }
            val res = Translator.translate(p, t)
            if (res == null) { handler.post { dbg("⚠ فشلت الترجمة: ${Translator.lastError}") }; return@execute }
            val (tr, engine) = res
            if (engine != "fallback") TranslationCache.put(src, t, tr)   // don't freeze low-quality fallback results
            handler.post { if (id >= shownSeq) { shownSeq = id; bar?.text = tr; bar?.alpha = 1f } }
        }
    }

    // ---------------- full-page translation ----------------
    private fun pageDone(msg: String?, ok: Boolean = false) {
        pageBusy = false; pageShown = ok
        pageFab?.text = if (ok) "✕" else "页"
        if (msg != null) { AppLog.add(msg); android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show() }
    }

    private fun clearPage() { pageLayer?.removeAllViews(); pageDone(null) }

    private fun pageToggle() {
        if (pageBusy) return
        if (pageShown) { clearPage(); return }
        pageBusy = true; pageFab?.text = "…"
        val mine = listOf(zone, bar, fab, grip, pageFab, pageLayer)
        mine.forEach { it?.visibility = View.INVISIBLE }          // so the OCR does not read our own overlays
        handler.postDelayed({
            val bmp = try { grabFull() } catch (_: Exception) { null }
            mine.forEach { it?.visibility = if (capVisible) View.VISIBLE else View.INVISIBLE }
            if (bmp == null) { pageDone("⚠ ما فماش صورة للشاشة"); return@postDelayed }
            runPageOcr(bmp)
        }, 300)
    }

    private fun runPageOcr(bmp: Bitmap) {
        val src = p.getString("src", "zh")!!
        rec(src).process(InputImage.fromBitmap(bmp, 0)).addOnSuccessListener { res ->
            val boxes = ArrayList<PB>(); val texts = ArrayList<String>()
            for (b in res.textBlocks) {
                val t = b.text.replace("\n", " ").trim(); val r = b.boundingBox ?: continue
                val ok = if (src == "en") t.any { it.isLetter() } else t.count { it.code in 0x3040..0x9FFF || it.code in 0xAC00..0xD7AF } >= 1
                if (t.length >= 2 && ok) { boxes.add(PB(r, b.lines.size.coerceAtLeast(1))); texts.add(t) }
            }
            if (boxes.isEmpty()) { pageDone("ما لقيتش نص في الشاشة"); return@addOnSuccessListener }
            AppLog.add("页 OCR: ${boxes.size} نص")
            pool.execute {
                val tr = translatePage(src, texts)
                handler.post { if (tr == null) pageDone("⚠ فشلت ترجمة الصفحة: ${Translator.lastError}") else { drawPage(boxes, tr); pageDone(null, true) } }
            }
        }.addOnFailureListener { pageDone("⚠ OCR: ${it.message}") }
    }

    private fun translatePage(src: String, texts: List<String>): List<String>? {
        val out = arrayOfNulls<String>(texts.size); val miss = ArrayList<Int>()
        texts.forEachIndexed { i, t -> val c = TranslationCache.get(src, t); if (c != null) out[i] = c else miss.add(i) }
        if (miss.isNotEmpty()) {
            val r = Translator.translateBatch(p, miss.map { texts[it] }) ?: return null
            miss.forEachIndexed { k, i -> out[i] = r.first[k]; if (r.second && r.first[k].isNotBlank()) TranslationCache.put(src, texts[i], r.first[k]) }
        }
        return out.map { it ?: "" }
    }

    // dark-blue band exactly over each original text block, translation written on it (grows downward only if it does not fit)
    private fun drawPage(boxes: List<PB>, tr: List<String>) {
        val layer = pageLayer ?: return
        layer.removeAllViews()
        val dm = resources.displayMetrics; val sd = dm.scaledDensity
        boxes.forEachIndexed { i, b ->
            val t = tr[i]; if (t.isBlank()) return@forEachIndexed
            val pad = dp(3); val inner = dp(4)
            val left = (b.r.left - pad).coerceIn(0, dm.widthPixels - dp(40)); val top = (b.r.top - pad).coerceIn(0, dm.heightPixels - dp(20))
            val w = (b.r.width() + 2 * pad).coerceAtLeast(dp(70)).coerceAtMost(dm.widthPixels - left)
            val minH = b.r.height() + 2 * pad
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
            var sp = (b.r.height().toFloat() / b.lines / sd * 0.6f).coerceIn(11f, 24f)
            var h = 0
            while (true) {
                tp.textSize = sp * sd
                val lay = StaticLayout.Builder.obtain(t, 0, t.length, tp, (w - 2 * inner).coerceAtLeast(1)).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
                h = lay.height + 2 * pad
                if (h <= minH || sp <= 11f) break
                sp -= 1f
            }
            val fh = maxOf(minH, h).coerceAtMost(dm.heightPixels - top)
            val tv = TextView(this).apply {
                text = t; setTextColor(Color.WHITE); textSize = sp; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                textDirection = View.TEXT_DIRECTION_ANY_RTL; setPadding(inner, pad, inner, pad)
                background = GradientDrawable().apply { cornerRadius = dp(6).toFloat(); setColor(0xF2101A45.toInt()) }
            }
            layer.addView(tv, FrameLayout.LayoutParams(w, fh).apply { leftMargin = left; topMargin = top })
        }
    }

    override fun onDestroy() {
        running = false
        TranslationCache.flush()
        AppLog.add("الخدمة توقفت")
        handler.removeCallbacksAndMessages(null)
        try { vd?.release(); reader?.close(); proj?.stop() } catch (_: Exception) {}
        listOf(zone, bar, fab, grip, pageFab, pageLayer).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        super.onDestroy()
    }
}
