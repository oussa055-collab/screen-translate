package com.screentranslate

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val p by lazy { getSharedPreferences("p", 0) }
    private var zone: View? = null
    private var bar: TextView? = null
    private lateinit var zp: LP
    private lateinit var bp: LP

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (zone == null) show()
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, x: Int, y: Int) =
        LP(w, h, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun drag(f: (Int, Int) -> Unit): View.OnTouchListener {
        var lx = 0f; var ly = 0f
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_MOVE -> { f((e.rawX - lx).toInt(), (e.rawY - ly).toInt()); lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_UP -> save()
            }
            true
        }
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        // Capture zone: dashed frame, drag to move, corner handle to resize
        zp = lp(p.getInt("zw", dm.widthPixels * 8 / 10), p.getInt("zh", dp(90)), p.getInt("zx", dm.widthPixels / 10), p.getInt("zy", dm.heightPixels * 7 / 10))
        val z = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setStroke(dp(2), 0xFF7C4DFF.toInt(), dp(8).toFloat(), dp(5).toFloat())
                cornerRadius = dp(10).toFloat(); setColor(0x1A7C4DFF)
            }
            setOnTouchListener(drag { dx, dy -> zp.x += dx; zp.y += dy; wm.updateViewLayout(this, zp) })
        }
        val h = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF2979FF.toInt()) }
            setOnTouchListener(drag { dx, dy ->
                zp.width = (zp.width + dx).coerceAtLeast(dp(80)); zp.height = (zp.height + dy).coerceAtLeast(dp(40))
                wm.updateViewLayout(z, zp)
            })
        }
        z.addView(h, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.BOTTOM or Gravity.END))
        wm.addView(z, zp); zone = z
        // Translation bar: drag anywhere
        bp = lp(dm.widthPixels * 8 / 10, LP.WRAP_CONTENT, dm.widthPixels / 10, p.getInt("by", dm.heightPixels / 3))
        val b = TextView(this).apply {
            text = "هنا تظهر الترجمة"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            textSize = p.getInt("font", 20).toFloat(); setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xCC140F3C.toInt()) }
            setOnTouchListener(drag { _, dy -> bp.y += dy; wm.updateViewLayout(this, bp) })
        }
        wm.addView(b, bp); bar = b
    }

    private fun save() {
        p.edit().putInt("zx", zp.x).putInt("zy", zp.y).putInt("zw", zp.width).putInt("zh", zp.height).putInt("by", bp.y).apply()
    }

    override fun onDestroy() {
        zone?.let { wm.removeView(it) }; bar?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
