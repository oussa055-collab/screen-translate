package com.screentranslate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.widget.TextView

/** Text with a black outline: stays readable on any video without a background box. */
class OutlinedText(ctx: Context) : TextView(ctx) {
    override fun onDraw(c: Canvas) {
        val l = layout ?: return super.onDraw(c)
        val p = paint
        c.save()
        c.translate(totalPaddingLeft.toFloat(), totalPaddingTop.toFloat())
        p.style = Paint.Style.STROKE; p.strokeWidth = textSize / 7f; p.strokeJoin = Paint.Join.ROUND; p.color = Color.BLACK
        l.draw(c)
        p.style = Paint.Style.FILL; p.color = currentTextColor
        l.draw(c)
        c.restore()
    }
}
